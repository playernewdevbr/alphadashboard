# AlphaBot — Termos de Serviço e Política de Privacidade

Site estático em HTML, CSS e JavaScript, preparado para publicação no GitHub Pages.

## Arquivos
- `index.html` — conteúdo dos dois documentos e estrutura do site.
- `style.css` — aparência, cores, animações e adaptação para celular.
- `script.js` — alternância entre os documentos sem recarregar a página e navegação por teclado.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie os três arquivos (`index.html`, `style.css` e `script.js`) para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/(root)` e salve.
6. Aguarde a publicação e abra o endereço mostrado na seção Pages.

## Antes de publicar
Confira se a Política de Privacidade descreve fielmente os dados que a versão real do AlphaBot processa e armazena. Este modelo não substitui uma avaliação jurídica.
